# Dice Game
## Played by one person 
## Played normally with three dice. 
## But you have an option to play with four dice
    'faces' of the dice are in numbers
   
### Dice Description
        Die D4 has faces    1 - 4

        Die D6 has faces    1 - 6

        Die D8 has faces    1 - 8

        Die D10 has faces   1 - 10


We begin with three dice - D4, D6, D8.

* You are expected to roll all the dice at once on a dice board.

* The outcome of your roll displays different faces of each dice.

If all the faces of the dice happens to be the same, you win the game!

* You have the chance to roll the dice five times with an extra bonus of first trial

If all the faces of your dice are never the same, you lose!
   
#### You can add an extra dice - D10, if you want
##### Installation
You can install this package using pip: 
* 

#### This is an important section.
