'''Displays Options'''
def game_choice():
    '''Displays Options'''
    print('m'*15, 'Options available:', 'm'*15)
    print('1. Roll dice ')
    print('2. Play with Extra Dice ')
    print('3. Quit game ')
